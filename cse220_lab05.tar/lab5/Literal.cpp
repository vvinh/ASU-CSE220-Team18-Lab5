/********************************************
 *
 * CSE220 LS 12166 Lab5 - Team18
 * Nicholas Murray
 * Vivian Vinh
 * Timothy Zamora
 *
 **********************************************/

#include <iostream>
#include "Literal.h"

using namespace std;

// constructor
Literal::Literal() {
	// empty body
} // end Literal constructor

